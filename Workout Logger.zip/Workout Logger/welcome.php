<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
        <title>Workout Logs</title>  
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <link  href="Styles\Styles.css" rel="stylesheet" type="text/css">
    </head>  
    <body>
        <h1>Welcome</h1> 
            <p>
                You are now logged in!!!
            </p>
        <h2><a href = "workoutlog.html">Workout Log Homepage</a></h2>
    </body>
    <footer>
        <p>Current Trends and Projects in Computer Science - Group 6 - 2018</p>
    </footer>

</html>