<!--
Russell Lilljedahl
CMSC 495 Group 6
30 Jun 2018
config connection to database
-->

<?php
return array(
    'host' => 'localhost',
    'username' => 'root',
    'password' => '',
    'database' => 'cmsc_495'
    );
?>